close all;clear all; clc
Function_name='F1'; 
[lb,ub,dim,fobj]=CEC2017(Function_name); % CEC2017
N=100;  
MaxFEs = 10000* dim;
T=ceil(MaxFEs/N);
[ala_score,ala_pos,ala_curve]=ALA(N,T,lb,ub,dim,fobj);
[qeala_score,qeala_pos,qeala_curve]=QEALA(N,T,lb,ub,dim,fobj);
display(['The best fitness of ALA is: ', num2str(ala_score)]);
display(['The best fitness of QEALA is: ', num2str(qeala_score)]);
figure('Position',[454   445   694   297]);
subplot(1,2,1);
func_plot_cec2017(Function_name);
title(Function_name)
xlabel('x_1');
ylabel('x_2');
zlabel([Function_name,'( x_1 , x_2 )'])
grid on
subplot(1,2,2);
FEs_ala = N * (1:length(ala_curve));
FEs_qeala = N * (1:length(qeala_curve));
semilogy(FEs_ala, ala_curve, 'Color', 'b', 'LineWidth', 2);
hold on;
semilogy(FEs_qeala, qeala_curve, 'Color', 'r', 'LineWidth', 2);
xlim([0, MaxFEs]);
axis tight
title(Function_name)
xlabel('FEs')
ylabel('Best score obtained so far')
grid on
legend('ALA','QEALA')

