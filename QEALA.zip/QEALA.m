% Q-Learning Driven Artificial Lemming Algorithm with Elite Pool and Dynamic Vertical Crossover Strategy: A Case Study in Wind Power Forecasting
%                                                                                                     
%  Developed in MATLAB R2024a                                                                 
%                                                                                                     
%  Author:Yaning Xiao, Yueqin Yin, Rui Zhong, Adam Slowik and Huiling Chen                                      
%                                                                                                                                                                                                                                                                                        
%_______________________________________________________________________________________________
% You can simply define your cost function in a seperate file and load its handle to fobj 
% The initial parameters that you need are:
%__________________________________________
% fobj = @YourCostFunction
% dim = number of your variables
% T = maximum number of iterations
% N = number of search agents
% lb=[lb1,lb2,...,lbn] where lbn is the lower bound of variable n
% ub=[ub1,ub2,...,ubn] where ubn is the upper bound of variable n
% If all the variables have equal lower bound you can just
% define lb and ub as two single numbers
% 2025-09-20
%______________________________________________________________________________________________
function [Score,Position,Convergence_curve]=QEALA(N,Max_iter,lb,ub,dim,fobj)
tic
X=initialization(N,dim,ub,lb);
Position=zeros(1,dim); % Best position
Score=inf; %Best score (initially infinite)
fitness=zeros(1,size(X,1));% Fitness of each individual
Convergence_curve=[];% Store convergence information
vec_flag=[1,-1]; % Directional flag

N1=N/2;
Elite_pool=[];

%% Record the initial optimal solution and fitness
for i=1:size(X,1)  
    fitness(1,i)=fobj(X(i,:));
    if fitness(1,i)<Score
        Position=X(i,:); Score=fitness(1,i);
    end
end

% initialize the params of Q-Learning
%% Improvement 1: Q-leanring 
action_num = 4; 
Q_table = zeros(action_num, action_num, N);
cur_state = randi(action_num, 1, N); 
gamma = 0.3;
lambda_initial = 0.9;
lambda_final = 0.1;

stagnation_window = 6;      
stagnation_counter = 0;      
last_best_score = inf;       

Iter=1; %Iteration number

%% Improvement 2: Elite pool strategy
[~,idx1]=sort(fitness);
second_best=X(idx1(2),:);
third_best=X(idx1(3),:);
sum1=0;
for i=1:N1
    sum1=sum1+X(idx1(i),:);
end

half_best_mean=sum1/N1;

Elite_pool(1,:)=Position;
Elite_pool(2,:)=second_best;
Elite_pool(3,:)=third_best;
Elite_pool(4,:)=half_best_mean;

%% Main optimization loop
while Iter<=Max_iter
    RB=randn(N,dim);  % Brownian motion
    F=vec_flag(floor(2*rand()+1)); % Random directional flag
    epsilon = 1 - log(1 + 9*Iter/Max_iter)/log(10);
    for i=1:N
            k1=randperm(4,1);
            current_state = cur_state(i);
            if rand() < epsilon
                action = randi(action_num); 
            else
                [~, action] = max(Q_table(current_state, :, i));
            end
            switch action
               case 1 
                   r1 = 2 * rand(1,dim) - 1;
                   Xnew= Elite_pool(k1,:)+RB(i,:).*F.*(r1.*(Position-X(i,:))+(1-r1).*(X(i,:)-X(randi(N),:))); 
               case 2
                   r2 = rand ()* (1 + sin(0.5 * Iter));
                   Xnew= X(i,:)+ F.* r2*(Position-X(randi(N),:));
               case 3 
                   radius = sqrt(sum((Position-X(i, :)).^2));
                   r3=rand();
                   spiral=radius*(sin(2*pi*r3)+cos(2*pi*r3));
                   Xnew=Position + F.* X(i,:).*spiral*rand;
               case 4
                   G=2*(sign(rand-0.5))*(1-Iter/Max_iter); 
                   Xnew= Position + F.* G.*Levy(dim).* (Position - X(i,:)) ;
            end
            Flag4ub=Xnew>ub;
            Flag4lb=Xnew<lb;
            Xnew=(Xnew.*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb; % Boundary correction
            newPopfit=fobj(Xnew); % Evaluate new solution
            reward = (newPopfit < fitness(i)) * 2 - 1; % +1 if improved, -1 otherwise
            if newPopfit < fitness(1,i)
                X(i,:)= Xnew;
                fitness(1,i)=newPopfit;
            end
        % Update Q-table
        next_maxQ = max(Q_table(action, :, i));
        lambda = (lambda_initial + lambda_final)/2 - (lambda_initial - lambda_final)/2 * cos(pi*(1 - Iter/Max_iter));
        Q_table(current_state, action, i) = Q_table(current_state, action, i) + lambda * (reward + gamma * next_maxQ - Q_table(current_state, action, i));
        cur_state(i) = action; % Update agent's current state
    end

      [best_fit, idx] = min(fitness);
      if best_fit < Score
            Score = best_fit;
            Position = X(idx,:);
      end
      
      if Score >= last_best_score
            stagnation_counter = stagnation_counter + 1;
        else
            stagnation_counter = 0;  
            last_best_score = Score;
      end
   %% Improvement 3: Dynamic vertical crossover restart strategy    
    if stagnation_counter >= stagnation_window  
        for i= 1:N
            RandIndexZ = randperm(dim);
            index1 = RandIndexZ(1);
            index2 = RandIndexZ(2);
            R1 = rand;
            MSv = X(i,:);
            MSv(index1) = R1.*X(i,index1) + (1 - R1).*X(i,index2);
            Flag_UB=MSv>ub; 
            Flag_LB=MSv<lb; 
            MSv=(MSv.*(~(Flag_UB+Flag_LB)))+ub.*Flag_UB+lb.*Flag_LB;
            mut_fitness = fobj(MSv);
            if mut_fitness<fitness(i)
                 fitness(i) = mut_fitness;
                 X(i,:) = MSv;
                 if fitness(i)<Score
                 Score=fitness(i);
                 Position = X(i,:);
                 end
            end
        end
        stagnation_counter = 0;
    end
        
    [~,idx1]=sort(fitness);
    second_best=X(idx1(2),:);
    third_best=X(idx1(3),:);
    sum1=0;
    for i=1:N1
        sum1=sum1+X(idx1(i),:);
    end

    half_best_mean=sum1/N1;

    Elite_pool(1,:)=Position;
    Elite_pool(2,:)=second_best;
    Elite_pool(3,:)=third_best;
    Elite_pool(4,:)=half_best_mean; 
    
    %% Record convergence curve
    Convergence_curve(Iter)=Score; 
    Iter=Iter+1; 
end
toc
end
function o=Levy(d)
beta=1.5;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u=randn(1,d)*sigma;v=randn(1,d);step=u./abs(v).^(1/beta);
o=step;
end